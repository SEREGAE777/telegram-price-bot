# Telegram Price Bot

Этот бот читает сообщения из канала `@BigSaleApple`, добавляет наценку и публикует в ваш канал `@topapple1`.

## 🚀 Деплой на Railway

1. Нажмите **Deploy to Railway**
2. Укажите переменные окружения:
   - API_ID
   - API_HASH
   - BOT_TOKEN
   - SOURCE_CHANNEL
   - TARGET_CHANNEL
   - ADD_NORMAL = 5000
   - ADD_16 = 10000
3. Готово!

